#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  7 16:54:45 2017

@author: kuangkun
"""

# import tensorflow as tf
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
from f_data_generation import *
from alg_baselines import *
import sklearn.metrics as skm
import os
from tensorflow.python.framework import ops
tf.set_random_seed(50)
# tf.set_random_seed(666)
# tf.random.set_seed(666)
def f_baseline_DGBR(train_or_test, X_in, Y_in):

    if train_or_test == 1:

        # First step: learn autoencoder by deep logistic regression with non-reweighting samples
        print('our AutoEncoder ...')
        learning_rate = 0.01; num_steps = 2000; tol = 1e-8
        # learning_rate = 0.005;
        # num_steps = 4000;
        # tol = 1e-8
        # tf.reset_default_graph()
        ops.reset_default_graph()
        X_encoder = f_autoencoder(1, 0, X_in, Y_in, learning_rate, num_steps, tol)
        #X_encoder = f_baseline_deepEmbedding(0, 0, X_in, Y_in, learning_rate, num_steps, tol)
        
        n,p = X_in.shape
        X_all = X_in
        for j in range(p):
            X_j = np.copy(X_in)
            X_j[:,j] = 0
            X_all = np.vstack((X_all,X_j))
        # tf.reset_default_graph()
        ops.reset_default_graph()
        X_all_encoder = f_autoencoder(0, 0, X_all, Y_in, learning_rate, num_steps, tol)
        #X_all_encoder = f_baseline_deepEmbedding(0, 0, X_all, Y_in, learning_rate, num_steps, tol)
        
        # Second step: global sample weights learning by global balancing on embedded confounders
        print('our GlobalBalancing ...')
        # tf.reset_default_graph()
        ops.reset_default_graph()
        learning_rate = 0.005; num_steps = 4000; tol = 1e-8
        GG= f_globalbalancing(1, X_in, X_all_encoder[0], learning_rate, num_steps, tol)
        
        # Third step: retaining preditive model by deep logistic regression with reweighted samples
        print('our AutoEncoder by weighting ...')
        learning_rate = 0.005; num_steps = 4000; tol = 1e-8
        # tf.reset_default_graph()
        ops.reset_default_graph()
        #X_encoder_w = f_autoencoder_weighted(1, 0, X_in, GG[0], Y_in, learning_rate, num_steps, tol)
        RMSE, F1 = f_autoencoder_weighted(1, 1, X_in, GG[0], Y_in, learning_rate, num_steps, tol)
        
    else:
        # tf.reset_default_graph()
        ops.reset_default_graph()
        RMSE, F1 = f_autoencoder_weighted(0, 1, X_in, np.ones([X_in.shape[0],1]), Y_in, 0, 0, 0)
        
    return RMSE, F1 

# It's not a easy work to tune a better parameter for simultanuous algorithm
def f_our_alg_simultanuous(train_or_test, X_in, Y_in, learning_rate, num_steps, tol):
        
    n,p = X_in.shape
    display_step = 200

    num_input = p
    
    num_hidden_1 = p/2 # 1st layer num features
    num_hidden_2 = p/2 # 2nd layer num features (the latent dim)
    
    # tf Graph input
    X = tf.placeholder("float", [None, num_input])
    Y = tf.placeholder("float", [None, 1])

    #global sample weights
    G = tf.Variable(tf.ones([n,1]))
    
    weights = {
        'encoder_h1': tf.Variable(tf.random_normal([num_input, num_hidden_1])),
        'encoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_hidden_2])),
        'decoder_h1': tf.Variable(tf.random_normal([num_hidden_2, num_hidden_1])),
        'decoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_input])),
    }
    biases = {
        'encoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'encoder_b2': tf.Variable(tf.random_normal([num_hidden_2])),
        'decoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'decoder_b2': tf.Variable(tf.random_normal([num_input])),
    }
    
    # Building the encoder
    def encoder(x):
        # Encoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['encoder_h1']),
                                       biases['encoder_b1']))
        # Encoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['encoder_h2']),
                                       biases['encoder_b2']))
        return layer_2
    
    
    # Building the decoder
    def decoder(x):
        # Decoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['decoder_h1']),
                                       biases['decoder_b1']))
        # Decoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['decoder_h2']),
                                       biases['decoder_b2']))
        return layer_2
    
    # Construct model
    encoder_op = encoder(X)
    decoder_op = decoder(encoder_op)
    
    # Prediction
    y_pred = decoder_op
    # encoder of X
    X_encoder = encoder_op
    # Targets (Labels) are the input data.
    y_true = X
    
    
    # prediction
    W = tf.Variable(tf.random_normal([num_hidden_2, 1]))
    b = tf.Variable(tf.random_normal([1]))
    
    hypothesis_all = tf.nn.sigmoid(tf.matmul(X_encoder, W) + b)
    hypothesis = tf.slice(hypothesis_all,[0,0],[n,1])
    
    saver = tf.train.Saver()
    sess = tf.Session()
    
    # input data
    X_feed = X_in
    Y_feed = Y_in
    for j in range(p):
        X_j = np.copy(X_in)
        X_j[:,j] = 0
        X_feed = np.vstack((X_feed,X_j))
    
    if (train_or_test == 1):
        #loss_autoencoder = tf.reduce_mean(tf.pow(y_true - y_pred, 2))
        #loss_autoencoder = tf.reduce_mean(tf.pow((G*G)*(tf.slice(y_true, [0,0],[n,p]) - tf.slice(y_pred, [0,0],[n,p])), 2))
        loss_autoencoder = tf.reduce_mean((G*G)*tf.pow((tf.slice(y_true, [0,0],[n,p]) - tf.slice(y_pred, [0,0],[n,p])), 2))
        loss_balancing = tf.constant(0, tf.float32)
        for j in range(1,p+1):
            X_j = tf.slice(X_encoder, [j*n,0],[n,num_hidden_2])
            I = tf.slice(X, [0,j-1],[n,1])
            balancing_j = tf.divide(tf.matmul(tf.transpose(X_j),G*G*I),tf.maximum(tf.reduce_sum(G*G*I),tf.constant(0.1))) - tf.divide(tf.matmul(tf.transpose(X_j),G*G*(1-I)),tf.maximum(tf.reduce_sum(G*G*(1-I)),tf.constant(0.1)))
            loss_balancing += tf.norm(balancing_j,ord=2)
        loss_predictive = -tf.reduce_sum(tf.divide((G*G)*(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis)),tf.reduce_sum(G*G)))
        loss_regulizer = (tf.reduce_sum(G*G)-n)**2  + 1000*(tf.reduce_sum(G*G-1))**2
        loss_l2reg = tf.reduce_sum(tf.square(W))+tf.reduce_sum(tf.square(weights['encoder_h1']))+tf.reduce_sum(tf.square(weights['encoder_h2']))+tf.reduce_sum(tf.square(weights['decoder_h1']))+tf.reduce_sum(tf.square(weights['decoder_h2']))
    
        # loss = 10.0*loss_predictive + 50.0/num_hidden_2*loss_autoencoder + 10.0/num_hidden_2*loss_balancing + 20.0/n*loss_regulizer + 0.0001*loss_l2reg
        loss = 10.0*loss_predictive + 5.0/num_hidden_2*loss_autoencoder + 5.0/num_hidden_2*loss_balancing + 20.0/n*loss_regulizer + 0.0001*loss_l2reg

        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)
    
        sess.run(tf.global_variables_initializer())
    
        l_pre = 0
        for i in range(1, num_steps+1):
            _, l, l_predictive, l_autoencoder, l_balancing, l_regulizer, l_regulizer_l2 = sess.run([optimizer, loss, loss_predictive, loss_autoencoder, loss_balancing, loss_regulizer, loss_l2reg], feed_dict={X: X_feed, Y:Y_feed})
            #print l, l_pre
            if abs(l-l_pre) <= tol:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_balancing, l_regulizer, l_regulizer_l2))
                break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_balancing, l_regulizer, l_regulizer_l2))
                '''
                W_final = sess.run(tf.multiply(G,G))
                fw = open('weight_from_tf_'+str(i)+'.txt', 'wb')
                for items in W_final:
                    fw.write(str(items[0])+'\r\n')
                fw.close()
                '''
        if not os.path.isdir('models/ourAlgComb/'):
            os.makedirs('models/ourAlgComb/')
        saver.save(sess, 'models/ourAlgComb/ourAlgComb.ckpt')
    else:
        #saver = tf.train.import_meta_graph('models/baseline_globalBalancing/baseline_globalBalancing.ckpt.meta')
        saver.restore(sess,'models/ourAlgComb/ourAlgComb.ckpt')
    
    RMSE = tf.sqrt(tf.reduce_mean((Y-hypothesis)**2))
    RMSE_error, Y_predict = sess.run([RMSE,hypothesis], feed_dict={X: X_feed, Y:Y_feed})
    F1_score = skm.f1_score(Y_in, Y_predict>0.5)
    return  RMSE_error, F1_score    

def f_autoencoder(train_or_test, predict_or_not, X_input, Y_input, learning_rate, num_steps, tol):
    
    n,num_input = X_input.shape
    
    num_hidden_1 = int(num_input/2) # 1st layer num features
    num_hidden_2 = int(num_input/2) # 2nd layer num features (the latent dim)
    
    display_step = 100
    
    X = tf.placeholder("float", [None, num_input])
    Y = tf.placeholder("float", [None, 1])
    
    weights = {
        'encoder_h1': tf.Variable(tf.random_normal([num_input, num_hidden_1])),
        'encoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_hidden_2])),
        'decoder_h1': tf.Variable(tf.random_normal([num_hidden_2, num_hidden_1])),
        'decoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_input])),
    }
    biases = {
        'encoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'encoder_b2': tf.Variable(tf.random_normal([num_hidden_2])),
        'decoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'decoder_b2': tf.Variable(tf.random_normal([num_input])),
    }
    
    # Building the encoder
    def encoder(x):
        # Encoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['encoder_h1']),
                                       biases['encoder_b1']))
        # Encoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['encoder_h2']),
                                       biases['encoder_b2']))
        return layer_2
    
    
    # Building the decoder
    def decoder(x):
        # Decoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['decoder_h1']),
                                       biases['decoder_b1']))
        # Decoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['decoder_h2']),
                                       biases['decoder_b2']))
        return layer_2
    
    # Construct model
    encoder_op = encoder(X)
    decoder_op = decoder(encoder_op)
    
    # Prediction
    y_pred = decoder_op
    # encoder of X
    X_encoder = encoder_op
    # Targets (Labels) are the input data.
    y_true = X
    
    # prediction
    W = tf.Variable(tf.random_normal([num_hidden_2, 1]))
    b = tf.Variable(tf.random_normal([1]))
    hypothesis = tf.sigmoid(tf.matmul(X_encoder, W) + b)
    
    saver = tf.train.Saver()
    sess = tf.Session()
    
    if train_or_test == 1:
        loss_autoencoder = tf.reduce_mean(tf.pow(y_true - y_pred, 2))
        # loss_predictive = -tf.reduce_mean(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis))
        loss_predictive = -tf.reduce_mean(Y * tf.log(tf.clip_by_value(hypothesis, 1e-8, 1.0)) + (1 - Y) * tf.log(
            tf.clip_by_value(1 - hypothesis, 1e-8, 1.0)))
        #loss_predictive = -tf.reduce_sum(tf.divide((G*G)*(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis)),tf.reduce_sum(G*G)))
        loss_l2reg = tf.reduce_sum(tf.square(W))+tf.reduce_sum(tf.square(weights['encoder_h1']))+tf.reduce_sum(tf.square(weights['encoder_h2']))+tf.reduce_sum(tf.square(weights['decoder_h1']))+tf.reduce_sum(tf.square(weights['decoder_h2']))
        
        loss = 1.0*loss_predictive + 10.0/num_hidden_2*loss_autoencoder + 0.0001*loss_l2reg
        # loss = 1.0 * loss_predictive + 0.5 * loss_autoencoder + 0.0001 * loss_l2reg
        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)
        
        sess.run(tf.global_variables_initializer())
    
        l_pre = 0
        for i in range(1, num_steps+1):
            _, l, l_predictive, l_autoencoder, l_l2reg = sess.run([optimizer, loss, loss_predictive, loss_autoencoder,loss_l2reg], feed_dict={X: X_input, Y:Y_input})
            if abs(l-l_pre) <= tol:
                print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
                break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
            
        if not os.path.isdir('models/autoencoder/'):
            os.makedirs('models/autoencoder/')
        saver.save(sess, 'models/autoencoder/autoencoder.ckpt')
    else:
        #saver.restore(sess, 'model/autoencoder.ckpt')
        #saver = tf.train.import_meta_graph('models/autoencoder/autoencoder.ckpt.meta')
        saver.restore(sess,'models/autoencoder/autoencoder.ckpt')
    
    if predict_or_not == 1:
        RMSE = tf.sqrt(tf.reduce_mean((Y-hypothesis)**2))
        RMSE_error, Y_predict = sess.run([RMSE,hypothesis], feed_dict={X: X_input, Y:Y_input})
        F1_score = skm.f1_score(Y_input, Y_predict>0.5)
        return  RMSE_error, F1_score
    
    return sess.run([X_encoder], feed_dict = {X:X_input})

def f_globalbalancing(train_or_test, X_input, X_encoder_input, learning_rate, num_steps, tol):
    n,p = X_input.shape
    n_e, p_e = X_encoder_input.shape
    
    display_step = 100
    
    X = tf.placeholder("float", [None, p])
    X_encoder = tf.placeholder("float", [None, p_e])
    
    G = tf.Variable(tf.ones([n,1]))

    loss_balancing = tf.constant(0, tf.float32)
    for j in range(1,p+1):
        X_j = tf.slice(X_encoder, [j*n,0],[n,p_e])
        I = tf.slice(X, [0,j-1],[n,1])
        balancing_j = tf.divide(tf.matmul(tf.transpose(X_j),G*G*I),tf.maximum(tf.reduce_sum(G*G*I),tf.constant(0.1))) - tf.divide(tf.matmul(tf.transpose(X_j),G*G*(1-I)),tf.maximum(tf.reduce_sum(G*G*(1-I)),tf.constant(0.1)))
        # balancing_j = tf.divide(
        #     tf.matmul(tf.transpose(G * G), tf.matmul(I, tf.cast(np.ones((1, p_e)), tf.float32)) * X_j),
        #     tf.constant(n, tf.float32)) - tf.divide(tf.matmul(tf.transpose(G * G), I),
        #                                             tf.reduce_sum(G * G)) * tf.divide(
        #     tf.matmul(tf.transpose(G * G), X_j), tf.constant(n, tf.float32))
        loss_balancing += tf.norm(balancing_j,ord=2)
    loss_regulizer = (tf.reduce_sum(G*G)-n)**2 + 10*(tf.reduce_sum(G*G-1))**2#
    
    loss = loss_balancing + 0.0001*loss_regulizer
    
    optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)
    
    saver = tf.train.Saver()
    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

    if train_or_test == 1:
        l_pre = 0
        for i in range(1, num_steps+1):
            _, l, l_balancing, l_regulizer = sess.run([optimizer, loss, loss_balancing, loss_regulizer], feed_dict={X: X_input, X_encoder: X_encoder_input})
            if abs(l-l_pre) <= tol:
                print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f' % (i, l, l_balancing, l_regulizer))
                break
            l_pre = l
            if l_balancing < 0.05:
                print('Good enough ... Step %i: Minibatch Loss: %f ... %f ... %f' % (i, l, l_balancing, l_regulizer))
                break
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f' % (i, l, l_balancing, l_regulizer))
                '''
                W_final = sess.run(G)
                fw = open('weight_from_tf_'+str(i)+'.txt', 'wb')
                for items in W_final:
                    fw.write(str(items[0])+'\r\n')
                fw.close()
                '''
        if not os.path.isdir('models/globalancing/'):
            os.makedirs('models/globalancing/')
        saver.save(sess, 'models/globalancing/globalancing.ckpt')
    else:
        #saver = tf.train.import_meta_graph('models/globalancing/globalancing.ckpt.meta')
        saver.restore(sess,'models/globalancing/globalancing.ckpt')
    
    return sess.run([G], feed_dict = {X:X_input, X_encoder:X_encoder_input})

def f_autoencoder_weighted(train_or_test, predict_or_not, X_input, G_input, Y_input, learning_rate, num_steps, tol):
    
    n,num_input = X_input.shape
    
    num_hidden_1 = int(num_input/2) # 1st layer num features
    num_hidden_2 = int(num_input/2) # 2nd layer num features (the latent dim)
    
    display_step = 100
    
    X = tf.placeholder("float", [None, num_input])
    Y = tf.placeholder("float", [None, 1])
    G = tf.placeholder("float", [None, 1])
    
    weights = {
        'encoder_h1': tf.Variable(tf.random_normal([num_input, num_hidden_1])),
        'encoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_hidden_2])),
        'decoder_h1': tf.Variable(tf.random_normal([num_hidden_2, num_hidden_1])),
        'decoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_input])),
    }
    biases = {
        'encoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'encoder_b2': tf.Variable(tf.random_normal([num_hidden_2])),
        'decoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'decoder_b2': tf.Variable(tf.random_normal([num_input])),
    }
    
    # Building the encoder
    def encoder(x):
        # Encoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['encoder_h1']),
                                       biases['encoder_b1']))
        # Encoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['encoder_h2']),
                                       biases['encoder_b2']))
        return layer_2
    
    
    # Building the decoder
    def decoder(x):
        # Decoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['decoder_h1']),
                                       biases['decoder_b1']))
        # Decoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['decoder_h2']),
                                       biases['decoder_b2']))
        return layer_2
    
    # Construct model
    encoder_op = encoder(X)
    decoder_op = decoder(encoder_op)
    
    # Prediction
    y_pred = decoder_op
    # encoder of X
    X_encoder = encoder_op
    # Targets (Labels) are the input data.
    y_true = X
    
    # prediction
    W = tf.Variable(tf.random_normal([num_hidden_2, 1]))
    b = tf.Variable(tf.random_normal([1]))
    hypothesis = tf.sigmoid(tf.matmul(X_encoder, W) + b)
    
    saver = tf.train.Saver()
    sess = tf.Session()
    
    if train_or_test == 1:
        #loss_autoencoder = tf.reduce_sum(tf.divide((G*G*tf.pow((y_true - y_pred),2)),tf.reduce_sum(G*G)))
        loss_autoencoder = tf.reduce_mean(tf.pow((G*G)*(y_true - y_pred), 2))
        #loss_predictive = -tf.reduce_mean(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis))
        # loss_predictive = -tf.reduce_sum(tf.divide((G*G)*(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis)),tf.reduce_sum(G*G)))
        loss_predictive = -tf.reduce_sum(tf.divide(G * G * (
                    Y * tf.log(tf.clip_by_value(hypothesis, 1e-8, 1)) + (1 - Y) * tf.log(
                tf.clip_by_value(1 - hypothesis, 1e-8, 1))), tf.reduce_sum(G * G)))
        loss_l2reg = tf.reduce_sum(tf.square(W))+tf.reduce_sum(tf.square(weights['encoder_h1']))+tf.reduce_sum(tf.square(weights['encoder_h2']))+tf.reduce_sum(tf.square(weights['decoder_h1']))+tf.reduce_sum(tf.square(weights['decoder_h2']))
        
        loss = 1*loss_predictive + 15.0/num_hidden_2*loss_autoencoder + 0.0005*loss_l2reg
        # loss = 1 * loss_predictive + 15 * loss_autoencoder + 0.0005 * loss_l2reg
        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)
        
        sess.run(tf.global_variables_initializer())
        
        print(sess.run([tf.reduce_sum(G*G)],feed_dict={G:G_input}))
        l_pre = 0
        for i in range(1, num_steps+1):
            _, l, l_predictive, l_autoencoder, l_l2reg = sess.run([optimizer, loss, loss_predictive, loss_autoencoder,loss_l2reg], feed_dict={X: X_input, G:G_input, Y:Y_input})
            #if abs(l-l_pre) <= tol:
            #    print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
            #    break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
            
        if not os.path.isdir('models/autoencoder_weighted/'):
            os.makedirs('models/autoencoder_weighted/')
        saver.save(sess, 'models/autoencoder_weighted/autoencoder_weighted.ckpt')
    else:
        #saver.restore(sess, 'model/autoencoder.ckpt')
        #saver = tf.train.import_meta_graph('models/autoencoder_weighted/autoencoder_weighted.ckpt.meta')
        saver.restore(sess,'models/autoencoder_weighted/autoencoder_weighted.ckpt')
    
    if predict_or_not == 1:
        RMSE = tf.sqrt(tf.reduce_mean((Y-hypothesis)**2))
        RMSE_error, Y_predict = sess.run([RMSE,hypothesis], feed_dict={X: X_input, Y:Y_input})
        F1_score = skm.f1_score(Y_input, Y_predict>0.5)
        return  RMSE_error, F1_score
    
    return sess.run([X_encoder], feed_dict = {X:X_input})
