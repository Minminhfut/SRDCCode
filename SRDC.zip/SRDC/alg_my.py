


#!/usr/bin/env python2
# -*- coding: utf-8 -*-


import tensorflow as tf
import numpy as np
from f_data_generation import *
from alg_baselines import *
import sklearn.metrics as skm
import os

def f_my_SRDC(train_or_test, X_in, Y_in):
    if train_or_test == 1:

        # First step: learn autoencoder by deep logistic regression with non-reweighting samples
        print('our AutoEncoder ...')
        learning_rate = 0.01;
        num_steps = 2000;
        tol = 1e-8
        tf.reset_default_graph()
        X_encoder = f_autoencoder_SRDC(1, 0, X_in, Y_in, learning_rate, num_steps, tol)
        n, p = X_in.shape
        X_all = X_in
        for j in range(p):
            X_j = np.copy(X_in)
            X_j[:, j] = 0
            X_all = np.vstack((X_all, X_j))
        tf.reset_default_graph()
        X_all_encoder = f_autoencoder_SRDC(0, 0, X_all, Y_in, learning_rate, num_steps, tol)

        # Second step: global sample weights learning by global balancing on embedded confounders
        print('our GlobalBalancing ...')
        tf.reset_default_graph()
        learning_rate = 0.005;
        num_steps = 4000;
        tol = 1e-8
        GG = f_globalbalancing_SRDC(1, X_in, X_all_encoder[0], learning_rate, num_steps, tol)

        fw = open('Weight.txt', 'w')
        w = GG[0] * GG[0]
        raw, column = w.shape
        for i in range(raw):
            fw.write(','.join(map(str, w[i, :])) + '\r')
        fw.close()

        # Third step: retaining preditive model by deep logistic regression with reweighted samples
        print('our AutoEncoder by weighting ...')
        learning_rate = 0.005;
        num_steps = 4000;
        tol = 1e-8
        tf.reset_default_graph()
        # X_encoder_w = f_autoencoder_weighted(1, 0, X_in, GG[0], Y_in, learning_rate, num_steps, tol)
        RMSE, F1 = f_autoencoder_weighted_SRDC(1, 1, X_in, GG[0], Y_in, learning_rate, num_steps, tol)

    else:
        tf.reset_default_graph()
        RMSE, F1 = f_autoencoder_weighted_SRDC(0, 1, X_in, np.ones([X_in.shape[0], 1]), Y_in, 0, 0, 0)

    return RMSE, F1


def f_autoencoder_SRDC(train_or_test, predict_or_not, X_input, Y_input, learning_rate, num_steps, tol):
    n, num_input = X_input.shape

    num_hidden_1 = int(num_input / 2)  # 1st layer num features
    num_hidden_2 = int(num_input / 2)  # 2nd layer num features (the latent dim)

    display_step = 100

    X = tf.placeholder("float", [None, num_input])
    Y = tf.placeholder("float", [None, 1])

    weights = {
        'encoder_h1': tf.Variable(tf.random_normal([num_input, num_hidden_1])),
        'encoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_hidden_2])),
        'decoder_h1': tf.Variable(tf.random_normal([num_hidden_2, num_hidden_1])),
        'decoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_input])),
    }
    biases = {
        'encoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'encoder_b2': tf.Variable(tf.random_normal([num_hidden_2])),
        'decoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'decoder_b2': tf.Variable(tf.random_normal([num_input])),
    }

    # Building the encoder
    def encoder(x):
        # Encoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['encoder_h1']),
                                       biases['encoder_b1']))
        # Encoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['encoder_h2']),
                                       biases['encoder_b2']))
        return layer_2

    # Building the decoder
    def decoder(x):
        # Decoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['decoder_h1']),
                                       biases['decoder_b1']))
        # Decoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['decoder_h2']),
                                       biases['decoder_b2']))
        return layer_2

    # Construct model
    encoder_op = encoder(X)
    decoder_op = decoder(encoder_op)

    # Prediction
    y_pred = decoder_op
    # encoder of X
    X_encoder = encoder_op
    # Targets (Labels) are the input data.
    y_true = X

    # prediction
    W = tf.Variable(tf.random_normal([num_hidden_2, 1]))
    b = tf.Variable(tf.random_normal([1]))
    hypothesis = tf.sigmoid(tf.matmul(X_encoder, W) + b)


    saver = tf.train.Saver()
    sess = tf.Session()

    if train_or_test == 1:
        loss_autoencoder = tf.reduce_mean(tf.pow(y_true - y_pred, 2))
        # loss_predictive = -tf.reduce_mean(Y * tf.log(hypothesis) + (1 - Y) * tf.log(1 - hypothesis))
        loss_predictive = -tf.reduce_mean(Y * tf.log(tf.clip_by_value(hypothesis, 1e-8, 1.0)) + (1 - Y) * tf.log(
            tf.clip_by_value(1 - hypothesis, 1e-8, 1.0)))

        # loss_predictive = -tf.reduce_sum(tf.divide((G*G)*(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis)),tf.reduce_sum(G*G)))
        loss_l2reg = tf.reduce_sum(tf.square(W)) + tf.reduce_sum(tf.square(weights['encoder_h1'])) + tf.reduce_sum(
            tf.square(weights['encoder_h2'])) + tf.reduce_sum(tf.square(weights['decoder_h1'])) + tf.reduce_sum(
            tf.square(weights['decoder_h2']))

        loss = 1.0 * loss_predictive + 10.0 / num_hidden_2 * loss_autoencoder + 0.0001 * loss_l2reg
        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)

        sess.run(tf.global_variables_initializer())

        l_pre = 0
        for i in range(1, num_steps + 1):
            _, l, l_predictive, l_autoencoder, l_l2reg = sess.run(
                [optimizer, loss, loss_predictive, loss_autoencoder, loss_l2reg], feed_dict={X: X_input, Y: Y_input})
            if abs(l - l_pre) <= tol:
                print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (
                i, l, l_predictive, l_autoencoder, l_l2reg))
                break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))

        if not os.path.isdir('models/autoencoderyang/'):
            os.makedirs('models/autoencoderyang/')
        saver.save(sess, 'models/autoencoderyang/autoencoderyang.ckpt')
    else:
        # saver.restore(sess, 'model/autoencoder.ckpt')
        # saver = tf.train.import_meta_graph('models/autoencoder/autoencoder.ckpt.meta')
        saver.restore(sess, 'models/autoencoderyang/autoencoderyang.ckpt')

    if predict_or_not == 1:
        RMSE = tf.sqrt(tf.reduce_mean((Y - hypothesis) ** 2))
        RMSE_error, Y_predict = sess.run([RMSE, hypothesis], feed_dict={X: X_input, Y: Y_input})
        F1_score = skm.f1_score(Y_input, Y_predict > 0.5)
        return RMSE_error, F1_score

    return sess.run([X_encoder], feed_dict={X: X_input})


def f_globalbalancing_SRDC(train_or_test, X_input, X_encoder_input, learning_rate, num_steps, tol):
    n, p = X_input.shape
    n_e, p_e = X_encoder_input.shape

    display_step = 100

    X = tf.placeholder("float", [None, p])
    X_encoder = tf.placeholder("float", [None, p_e])

    G = tf.Variable(tf.ones([n, 1]))


    loss_balancing = tf.constant(0, tf.float32)
    for j in range(1, p + 1):
        X_j = tf.slice(X_encoder, [j * n, 0], [n, p_e])
        I = tf.slice(X, [0, j - 1], [n, 1])
        balancing_j = tf.divide(tf.matmul(tf.transpose(X_j), G * G * I),
                                tf.maximum(tf.reduce_sum(G * G * I), tf.constant(0.1))) - tf.divide(
            tf.matmul(tf.transpose(X_j), G * G * (1 - I)), tf.maximum(tf.reduce_sum(G * G * (1 - I)), tf.constant(0.1)))

        loss_balancing += tf.norm(balancing_j, ord=2)
    loss_regulizer = (tf.reduce_sum(G * G) - n) ** 2 + 10 * (tf.reduce_sum(G * G - 1)) ** 2   #
    loss = 1*loss_balancing+ 0.0001 * loss_regulizer
    optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)

    saver = tf.train.Saver()
    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

    if train_or_test == 1:
        l_pre = 0
        for i in range(1, num_steps + 1):
            _, l, l_balancing, l_regulizer = sess.run([optimizer, loss, loss_balancing, loss_regulizer],
                                                      feed_dict={X: X_input, X_encoder: X_encoder_input})
            if abs(l - l_pre) <= tol:
                print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f' % (i, l, l_balancing, l_regulizer))
                break
            l_pre = l
            if l_balancing < 0.05:
                print('Good enough ... Step %i: Minibatch Loss: %f ... %f ... %f' % (i, l, l_balancing, l_regulizer))
                break
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f' % (i, l, l_balancing, l_regulizer))
                '''
                W_final = sess.run(G)
                fw = open('weight_from_tf_'+str(i)+'.txt', 'wb')
                for items in W_final:
                    fw.write(str(items[0])+'\r\n')
                fw.close()
                '''
        if not os.path.isdir('models/globalancingyang/'):
            os.makedirs('models/globalancingyang/')
        saver.save(sess, 'models/globalancingyang/globalancingyang.ckpt')
    else:
        # saver = tf.train.import_meta_graph('models/globalancing/globalancing.ckpt.meta')
        saver.restore(sess, 'models/globalancingyang/globalancingyang.ckpt')

    return sess.run([G], feed_dict={X: X_input, X_encoder: X_encoder_input})


def f_autoencoder_weighted_SRDC(train_or_test, predict_or_not, X_input, G_input, Y_input, learning_rate, num_steps, tol):
    n, num_input = X_input.shape
    X_input_2 = np.copy(X_input[0:int(n/2),:])
    num_hidden_1 = int(num_input / 2)  # 1st layer num features
    num_hidden_2 = int(num_input / 2)  # 2nd layer num features (the latent dim)

    display_step = 100

    X = tf.placeholder("float", [None, num_input])
    X_2 = tf.placeholder("float", [None, num_input])
    Y = tf.placeholder("float", [None, 1])
    G = tf.placeholder("float", [None, 1])


    weights = {
        'encoder_h1': tf.Variable(tf.random_normal([num_input, num_hidden_1])),
        'encoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_hidden_2])),
        'decoder_h1': tf.Variable(tf.random_normal([num_hidden_2, num_hidden_1])),
        'decoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_input])),
    }
    biases = {
        'encoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'encoder_b2': tf.Variable(tf.random_normal([num_hidden_2])),
        'decoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'decoder_b2': tf.Variable(tf.random_normal([num_input])),
    }

    # Building the encoder
    def encoder(x):
        # Encoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['encoder_h1']),
                                       biases['encoder_b1']))
        # Encoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['encoder_h2']),
                                       biases['encoder_b2']))
        return layer_2

    # Building the decoder
    def decoder(x):
        # Decoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['decoder_h1']),
                                       biases['decoder_b1']))
        # Decoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['decoder_h2']),
                                       biases['decoder_b2']))
        return layer_2

    # Construct model
    encoder_op = encoder(X)
    decoder_op = decoder(encoder_op)

    # Prediction
    y_pred = decoder_op
    # encoder of X
    X_encoder = encoder_op
    # Targets (Labels) are the input data.
    y_true = X

    # prediction
    W = tf.Variable(tf.random_normal([num_hidden_2, 1]))
    # W = tf.Variable(tf.random_uniform([num_hidden_2, 1]))
    # W = tf.Variable(tf.ones([num_hidden_2, 1]))
    b = tf.Variable(tf.random_normal([1]))
    hypothesis = tf.sigmoid(tf.matmul(X_encoder, W) + b)
    # W2 = tf.Variable(tf.random_uniform([num_hidden_2, 1]))
    # W2 = tf.Variable(tf.random_uniform([num_hidden_2, 1]))
    W2 = tf.Variable(tf.random_normal([num_hidden_2, 1]))
    b2 = tf.Variable(tf.random_normal([1]))
    # b2 = tf.Variable(tf.zeros([1]))
    hypothesis2 = tf.sigmoid(tf.matmul(X_encoder, W2) + b2)


    saver = tf.train.Saver()
    sess = tf.Session()

    if train_or_test == 1:
        loss_autoencoder = tf.reduce_mean(tf.pow((G * G) * (y_true - y_pred), 2))
        loss_predictive = -tf.reduce_sum(tf.divide(G * G * (
                    Y * tf.log(tf.clip_by_value(hypothesis, 1e-8, 1)) + (1 - Y) * tf.log(
                tf.clip_by_value(1 - hypothesis, 1e-8, 1))), tf.reduce_sum(G * G)))
        loss_predictive2 = -tf.reduce_sum(tf.divide(G * G * (
                Y * tf.log(tf.clip_by_value(hypothesis2, 1e-8, 1)) + (1 - Y) * tf.log(
            tf.clip_by_value(1 - hypothesis2, 1e-8, 1))), tf.reduce_sum(G * G)))

        loss_l2reg = tf.reduce_sum(tf.square(W))+tf.reduce_sum(tf.square(b))  +tf.reduce_sum(tf.square(W2))+tf.reduce_sum(tf.square(b2))  +tf.reduce_sum(tf.square(weights['encoder_h1'])) + tf.reduce_sum(
            tf.square(weights['encoder_h2'])) + tf.reduce_sum(tf.square(weights['decoder_h1'])) + tf.reduce_sum(
            tf.square(weights['decoder_h2']))

        lossb = tf.reduce_sum(tf.square(W - W2) )
        alpha = 0.5

        # loss = alpha * loss_predictive + 15.0 / num_hidden_2  * loss_autoencoder + 0.0005 * loss_l2reg +alpha * loss_predictive2 + 1e-3*lossb
        loss = alpha * loss_predictive + 5 * loss_autoencoder + 0.0005 * loss_l2reg + alpha * loss_predictive2 + 1e-3 * lossb
        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)

        sess.run(tf.global_variables_initializer())

        # print(sess.run([tf.reduce_sum(G * G)], feed_dict={G: G_input}))
        print('----------------------------------------------------------------' )
        for i in range(1, num_steps + 1):
            _, l, l_predictive, l_autoencoder, l_l2reg = sess.run(
                [optimizer, loss, loss_predictive, loss_predictive2, lossb],
                feed_dict={X: X_input, G: G_input, Y: Y_input, X_2: X_input_2})
            # if abs(l-l_pre) <= tol:
            #    print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
            #    break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
        print('----------------------------------------------------------------')
        if not os.path.isdir('models/autoencoder_weightedyang/'):
            os.makedirs('models/autoencoder_weightedyang/')
        saver.save(sess, 'models/autoencoder_weightedyang/autoencoder_weightedyang.ckpt')
    else:
        # saver.restore(sess, 'model/autoencoder.ckpt')
        # saver = tf.train.import_meta_graph('models/autoencoder_weighted/autoencoder_weighted.ckpt.meta')
        saver.restore(sess, 'models/autoencoder_weightedyang/autoencoder_weightedyang.ckpt')

    if predict_or_not == 1:
        RMSE = tf.sqrt(tf.reduce_mean((Y - hypothesis) ** 2))
        RMSE_error, Y_predict = sess.run([RMSE, hypothesis], feed_dict={X: X_input, Y: Y_input, X_2: X_input_2,G: G_input})

        F1_score = skm.f1_score(Y_input, Y_predict>0.5)

        return RMSE_error, F1_score

    return sess.run([X_encoder], feed_dict={X: X_input})



#
#
