# import tensorflow as tf
import numpy as np
import sklearn.metrics as skm
import os
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
tf.set_random_seed(666)  # reproducibility
# tf.random.set_seed(666)
def f_baseline_logisticRegression(train_or_test, X_in, Y_in, learning_rate, num_steps, tol):
    n,num_input = X_in.shape

    display_step = 200

    # tf Graph input (only pictures)
    X = tf.placeholder("float", [None, num_input])
    Y = tf.placeholder("float", [None, 1])

    # prediction
    W = tf.Variable(tf.random_normal([num_input, 1]))
    b = tf.Variable(tf.random_normal([1]))
    hypothesis = tf.nn.sigmoid(tf.matmul(X, W) + b)
    
    saver = tf.train.Saver()
    sess = tf.Session()
    
    if train_or_test == 1:
        
        # loss_predictive = -tf.reduce_mean(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis))
        loss_predictive = -tf.reduce_mean(Y * tf.log(tf.clip_by_value(hypothesis, 1e-8, 1.0)) + (1 - Y) * tf.log(
            tf.clip_by_value(1 - hypothesis, 1e-8, 1.0)))
        loss_l2reg = tf.reduce_sum(tf.abs(W))
        loss = loss_predictive + 0.01*loss_l2reg
    
        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)
    
        sess.run(tf.global_variables_initializer())

    
        l_pre = 0
        for i in range(1, num_steps+1):
            _, l, l2reg = sess.run([optimizer, loss, loss_l2reg], feed_dict={X: X_in, Y:Y_in})
            if abs(l-l_pre) <= tol:
                print('Converge ... Step %i: Minibatch Loss: %f ... %f' % (i, l, l2reg))
                break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f' % (i, l, l2reg))
        if not os.path.isdir('models/baseline_logisticRegression/'):
            os.makedirs('models/baseline_logisticRegression/')
        saver.save(sess, 'models/baseline_logisticRegression/baseline_logisticRegression.ckpt')
    else:
        #saver = tf.train.import_meta_graph('models/baseline_logisticRegression/baseline_logisticRegression.ckpt.meta')
        saver.restore(sess,'models/baseline_logisticRegression/baseline_logisticRegression.ckpt')

    RMSE = tf.sqrt(tf.reduce_mean((Y-hypothesis)**2))
    RMSE_error, Y_predict = sess.run([RMSE,hypothesis], feed_dict={X: X_in, Y:Y_in})
    F1_score = skm.f1_score(Y_in, Y_predict>0.5)
    beta = sess.run([W], feed_dict={X: X_in, Y: Y_in})
    return  RMSE_error, F1_score



def f_baseline_deepEmbedding(train_or_test, predict_or_not, X_in, Y_in, learning_rate, num_steps, tol):
    n,num_input = X_in.shape

    display_step = 200

    # Network Parameters
    num_hidden_1 = int(num_input/2) # 1st layer num features
    num_hidden_2 = int(num_input/2) # 2nd layer num features (the latent dim)

    # tf Graph input (only pictures)
    X = tf.placeholder("float", [None, num_input])
    Y = tf.placeholder("float", [None, 1])

    weights = {
        'encoder_h1': tf.Variable(tf.random_normal([num_input, num_hidden_1])),
        'encoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_hidden_2])),
        'decoder_h1': tf.Variable(tf.random_normal([num_hidden_2, num_hidden_1])),
        'decoder_h2': tf.Variable(tf.random_normal([num_hidden_1, num_input])),
    }
    biases = {
        'encoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'encoder_b2': tf.Variable(tf.random_normal([num_hidden_2])),
        'decoder_b1': tf.Variable(tf.random_normal([num_hidden_1])),
        'decoder_b2': tf.Variable(tf.random_normal([num_input])),
    }

    # Building the encoder
    def encoder(x):
        # Encoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['encoder_h1']),
                                       biases['encoder_b1']))
        # Encoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['encoder_h2']),
                                       biases['encoder_b2']))
        return layer_2


    # Building the decoder
    def decoder(x):
        # Decoder Hidden layer with sigmoid activation #1
        layer_1 = tf.nn.sigmoid(tf.add(tf.matmul(x, weights['decoder_h1']),
                                       biases['decoder_b1']))
        # Decoder Hidden layer with sigmoid activation #2
        layer_2 = tf.nn.sigmoid(tf.add(tf.matmul(layer_1, weights['decoder_h2']),
                                       biases['decoder_b2']))
        return layer_2

    # Construct model
    encoder_op = encoder(X)
    decoder_op = decoder(encoder_op)

    # Prediction
    y_pred = decoder_op
    # encoder of X
    X_encoder = encoder_op
    # Targets (Labels) are the input data.
    y_true = X

    # prediction
    W = tf.Variable(tf.random_normal([num_hidden_2, 1]))
    b = tf.Variable(tf.random_normal([1]))
    hypothesis = tf.sigmoid(tf.matmul(X_encoder, W) + b)
    
    saver = tf.train.Saver()
    sess = tf.Session()
    
    # if training, we need to train a model and save it
    # if testing, we load the saved model
    if train_or_test == 1:

        loss_autoencoder = tf.reduce_mean(tf.pow(y_true - y_pred, 2))
        # loss_predictive = -tf.reduce_mean(Y*tf.log(hypothesis)+(1-Y)*tf.log(1-hypothesis))
        loss_predictive = -tf.reduce_mean(Y * tf.log(tf.clip_by_value(hypothesis, 1e-8, 1.0)) + (1 - Y) * tf.log(
            tf.clip_by_value(1 - hypothesis, 1e-8, 1.0)))
        loss_l2reg = tf.reduce_sum(tf.square(W))+tf.reduce_sum(tf.square(weights['encoder_h1']))+tf.reduce_sum(tf.square(weights['encoder_h2']))+tf.reduce_sum(tf.square(weights['decoder_h1']))+tf.reduce_sum(tf.square(weights['decoder_h2']))
    
        # loss = 1*loss_predictive + 10.0/num_hidden_2*loss_autoencoder + 0.0001*loss_l2reg
        loss = 1 * loss_predictive + 1.0  * loss_autoencoder + 0.0001 * loss_l2reg
    
        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)
    
        sess.run(tf.global_variables_initializer())

        l_pre = 0
        for i in range(1, num_steps+1):
            _, l, l_predictive, l_autoencoder, l_l2reg = sess.run([optimizer, loss, loss_predictive, loss_autoencoder,loss_l2reg], feed_dict={X: X_in, Y:Y_in})
            if abs(l-l_pre) <= tol:
                print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
                break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f' % (i, l, l_predictive, l_autoencoder, l_l2reg))
        if not os.path.isdir('models/baseline_deepEmbedding/'):
            os.makedirs('models/baseline_deepEmbedding/')
        saver.save(sess, 'models/baseline_deepEmbedding/baseline_deepEmbedding.ckpt')
    else:
        #saver = tf.train.import_meta_graph('models/baseline_deepEmbedding/baseline_deepEmbedding.ckpt.meta')
        saver.restore(sess,'models/baseline_deepEmbedding/baseline_deepEmbedding.ckpt')
    
    if predict_or_not:
        RMSE = tf.sqrt(tf.reduce_mean((Y-hypothesis)**2))
        RMSE_error, Y_predict = sess.run([RMSE,hypothesis], feed_dict={X: X_in, Y:Y_in})
        F1_score = skm.f1_score(Y_in, Y_predict>0.5)
        return  RMSE_error, F1_score
    
    return sess.run([X_encoder], feed_dict = {X:X_in})

def f_baseline_CRLR(train_or_test, X_in, Y_in, learning_rate, num_steps, tol):
    n,p = X_in.shape

    display_step = 200

    X = tf.placeholder("float", [None, p])
    Y = tf.placeholder("float", [None, 1])
    G = tf.Variable(tf.ones([n,1]))

    # prediction
    W = tf.Variable(tf.random_normal([p, 1]))
    b = tf.Variable(tf.random_normal([1]))
    hypothesis_all = tf.nn.sigmoid(tf.matmul(X, W) + b)
    hypothesis = tf.slice(hypothesis_all,[0,0],[n,1])
    
    saver = tf.train.Saver([W]+[b])
    sess = tf.Session()
    
    if train_or_test == 1:
        loss_balancing = tf.constant(0, tf.float32)
        for j in range(1,p+1):
            X_j = tf.slice(X, [j*n,0],[n,p])
            I = tf.slice(X, [0,j-1],[n,1])
            balancing_j = tf.divide(tf.matmul(tf.transpose(X_j),G*G*I),tf.maximum(tf.reduce_sum(G*G*I),tf.constant(0.1))) - tf.divide(tf.matmul(tf.transpose(X_j),G*G*(1-I)),tf.maximum(tf.reduce_sum(G*G*(1-I)),tf.constant(0.1)))
            # balancing_j = tf.divide(
            #     tf.matmul(tf.transpose(G * G), tf.matmul(I, tf.cast(np.ones((1, p)), tf.float32)) * X_j),
            #     tf.constant(n, tf.float32)) - tf.divide(tf.matmul(tf.transpose(G * G), I),
            #                                             tf.reduce_sum(G * G)) * tf.divide(
            #     tf.matmul(tf.transpose(G * G), X_j), tf.constant(n, tf.float32))
            loss_balancing += tf.norm(balancing_j,ord=2)
        loss_regulizer = (tf.reduce_sum(G*G)-n)**2
        loss_regulizer_l2 = (tf.reduce_sum(G*G))**2
        loss_l2reg = tf.reduce_sum(tf.abs(W))
        loss_predictive = -tf.reduce_sum(tf.divide(G*G*(Y*tf.log(tf.clip_by_value(hypothesis,1e-8,1))+(1-Y)*tf.log(tf.clip_by_value(1-hypothesis,1e-8,1))),tf.reduce_sum(G*G)))

        # loss_regulizer =  (tf.reduce_sum(G * G) - n) ** 2 + 1000 * (tf.reduce_sum(G * G - 1)) ** 2
        loss_regulizer = (tf.reduce_sum(G * G) - 1) ** 2
        # loss = 1*loss_predictive + 10000.0/p*loss_balancing + 0.001/n*loss_regulizer + 0.01*loss_l2reg
        loss = 1 * loss_predictive + 10000.0 / p * loss_balancing + 20.0/ n * loss_regulizer + 0.01 * loss_l2reg
    
        optimizer = tf.train.RMSPropOptimizer(learning_rate).minimize(loss)
        
        sess.run(tf.global_variables_initializer())

    
        X_feed = X_in
        for j in range(p):
            X_j = np.copy(X_in)
            X_j[:,j] = 0
            X_feed = np.vstack((X_feed,X_j))
        
        l_pre = 0
        for i in range(1, num_steps+1):
            _, l, l_predictive, l_balancing, l_regulizer, l_regulizer_l2 = sess.run([optimizer, loss, loss_predictive, loss_balancing, loss_regulizer, loss_regulizer_l2], feed_dict={X: X_feed, Y:Y_in})
            if abs(l-l_pre) <= tol:
                print('Converge ... Step %i: Minibatch Loss: %f ... %f ... %f ... %f ... %f' % (i, l, l_predictive, l_balancing, l_regulizer, l_regulizer_l2))
                break
            l_pre = l
            if i % display_step == 0 or i == 1:
                print('Step %i: Minibatch Loss: %f ... %f ... %f ... %f ... %f' % (i, l, l_predictive, l_balancing, l_regulizer, l_regulizer_l2))
                '''
                W_final = sess.run(G)
                fw = open('bl_weight_from_tf_'+str(i)+'.txt', 'wb')
                for items in W_final:
                    fw.write(str(items[0])+'\r\n')
                fw.close()
                '''
        if not os.path.isdir('models/baseline_globalBalancing/'):
            os.makedirs('models/baseline_globalBalancing/')
        saver.save(sess, 'models/baseline_globalBalancing/baseline_globalBalancing.ckpt')
        '''
        RMSE = tf.sqrt(tf.reduce_mean((Y-hypothesis_all)**2))
        RMSE_error, Y_predict = sess.run([RMSE,hypothesis_all], feed_dict={X: X_in, Y:Y_in})
        F1_score = skm.f1_score(Y_in, Y_predict>0.5)
        return  RMSE_error, F1_score
        '''
    else:
        #saver = tf.train.import_meta_graph('models/baseline_globalBalancing/baseline_globalBalancing.ckpt.meta')
        saver.restore(sess,'models/baseline_globalBalancing/baseline_globalBalancing.ckpt')
        
    hypothesis_p = tf.nn.sigmoid(tf.matmul(X, W) + b)
    RMSE = tf.sqrt(tf.reduce_mean((Y-hypothesis_p)**2))
    RMSE_error, Y_predict = sess.run([RMSE,hypothesis_p], feed_dict={X: X_in, Y:Y_in})
    F1_score = skm.f1_score(Y_in, Y_predict>0.5)
    beta = sess.run([W], feed_dict={X: X_in, Y: Y_in})
    # print(beta)
    return  RMSE_error, F1_score





